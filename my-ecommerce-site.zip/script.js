let cartCount = 0;
const cartCountEl = document.getElementById('cart-count');

document.querySelectorAll('.add-to-cart').forEach(button => {
  button.addEventListener('click', () => {
    cartCount++;
    cartCountEl.textContent = cartCount;
    alert('Item added to cart!');
  });
});